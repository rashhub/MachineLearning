In order to complete this homework you will need Python 3 and Theano installed.
One very easy way to get this environment installed is to use Anaconda:
https://www.continuum.io/downloads
Please note that the Jupyter notebook is written in Python 3. 

For a quickstart with Jupyter:
https://jupyter.readthedocs.io/en/latest/content-quickstart.html

To start working on the homework, in the directory in which you
unpacked the homework files run:
	jupyter notebook hw2.ipynb

This will open a browser window that you can use as a development environment.
  